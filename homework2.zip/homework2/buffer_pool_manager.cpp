#include "buffer/buffer_pool_manager.h"

namespace cmudb {

BufferPoolManager::BufferPoolManager(size_t pool_size,
                                                 DiskManager *disk_manager,
                                                 LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager),
      log_manager_(log_manager) {
  pages_ = new Page[pool_size_];
  page_table_ = new ExtendibleHash<page_id_t, Page *>(BUCKET_SIZE);
  replacer_ = new LRUReplacer<Page *>;
  free_list_ = new std::list<Page *>;


  for (size_t i = 0; i < pool_size_; ++i) {
    free_list_->push_back(&pages_[i]);
  }
}


BufferPoolManager::~BufferPoolManager() {
  delete[] pages_;
  delete page_table_;
  delete replacer_;
  delete free_list_;
}

Page *BufferPoolManager::FetchPage(page_id_t page_id) {
  lock_guard<mutex> lck(tlock);
  Page *temp = nullptr;
  if (page_table_->Find(page_id,temp)) { //1.1
    temp->pin_count_++;
    replacer_->Erase(temp);
    return temp;
  }

  temp = GetVictimPage();
  if (temp == nullptr) return temp;
  if (temp->is_dirty_) {
    disk_manager_->WritePage(temp->GetPageId(),temp->data_);
  }
  page_table_->Remove(temp->GetPageId());
  page_table_->Insert(page_id,temp);
  disk_manager_->ReadPage(page_id,temp->data_);
  temp->pin_count_ = 1;
  temp->is_dirty_ = false;
  temp->page_id_= page_id;

  return temp;
}

bool BufferPoolManager::UnpinPage(page_id_t page_id, bool is_dirty) {
  lock_guard<mutex> lck(tlock);
  Page *temp = nullptr;
  page_table_->Find(page_id,temp);
  if (temp == nullptr) {
    return false;
  }
  temp->is_dirty_ = is_dirty;
  if (temp->GetPinCount() <= 0) {
    return false;
  }
  ;
  if (--temp->pin_count_ == 0) {
    replacer_->Insert(temp);
  }
  return true;
}

bool BufferPoolManager::FlushPage(page_id_t page_id) {
  lock_guard<mutex> lck(tlock);
  Page *temp = nullptr;
  page_table_->Find(page_id,temp);
  if (temp == nullptr || temp->page_id_ == INVALID_PAGE_ID) {
    return false;
  }
  if (temp->is_dirty_) {
    disk_manager_->WritePage(page_id,temp->GetData());
    temp->is_dirty_ = false;
  }

  return true;
}
bool BufferPoolManager::DeletePage(page_id_t page_id) {
  lock_guard<mutex> lck(tlock);
  Page *temp = nullptr;
  page_table_->Find(page_id,temp);
  if (temp != nullptr) {
    if (temp->GetPinCount() > 0) {
      return false;
    }
    replacer_->Erase(temp);
    page_table_->Remove(page_id);
    temp->is_dirty_= false;
    temp->ResetMemory();
    free_list_->push_back(temp);
  }
  disk_manager_->DeallocatePage(page_id);
  return true;
}

Page *BufferPoolManager::NewPage(page_id_t &page_id) {
  lock_guard<mutex> lck(tlock);
  Page *temp = nullptr;
  temp = GetVictimPage();
  if (temp == nullptr) return temp;

  page_id = disk_manager_->AllocatePage();
  if (temp->is_dirty_) {
    disk_manager_->WritePage(temp->GetPageId(),temp->data_);
  }
  page_table_->Remove(temp->GetPageId());
  page_table_->Insert(page_id,temp);

  temp->page_id_ = page_id;
  temp->ResetMemory();
  temp->is_dirty_ = false;
  temp->pin_count_ = 1;

  return temp;
}

Page *BufferPoolManager::GetVictimPage() {
  Page *temp = nullptr;
  if (free_list_->empty()) {
    if (replacer_->Size() == 0) {
      return nullptr;
    }
    replacer_->Victim(temp);
  } else {
    temp = free_list_->front();
    free_list_->pop_front();
    assert(temp->GetPageId() == INVALID_PAGE_ID);
  }
  assert(temp->GetPinCount() == 0);
  return temp;
}

} // namespace cmudb
