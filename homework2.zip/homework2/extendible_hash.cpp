#include <list>

#include "hash/extendible_hash.h"
#include "page/page.h"
#include"extendible_hash.h"
using namespace std;

namespace cmudb {

template <typename K, typename V>
ExtendibleHash<K, V>::ExtendibleHash(size_t size) :  globalDepth(0),bucketSize(size),bucketNum(1) {
  buckets.push_back(make_shared<Bucket>(0));
}
template<typename K, typename V>
ExtendibleHash<K, V>::ExtendibleHash() {
  ExtendibleHash(64);
}

template <typename K, typename V>
size_t ExtendibleHash<K, V>::HashKey(const K &key) const{
  return hash<K>{}(key);
}

template <typename K, typename V>
int ExtendibleHash<K, V>::GetGlobalDepth() const{
  lock_guard<mutex> lock(tlock);
  return globalDepth;
}

template <typename K, typename V>
int ExtendibleHash<K, V>::GetLocalDepth(int bucket_id) const {
  if (buckets[bucket_id]) {
    lock_guard<mutex> lck(buckets[bucket_id]->tlock);
    if (buckets[bucket_id]->tmap.size() == 0) return -1;
    return buckets[bucket_id]->localDepth;
  }
  return -1;
}

template <typename K, typename V>
int ExtendibleHash<K, V>::GetNumBuckets() const{
  lock_guard<mutex> lock(tlock);
  return bucketNum;
}

template <typename K, typename V>
bool ExtendibleHash<K, V>::Find(const K &key, V &value) {

  int idx = getIdx(key);
  lock_guard<mutex> lck(buckets[idx]->tlock);
  if (buckets[idx]->tmap.find(key) != buckets[idx]->tmap.end()) {
    value = buckets[idx]->tmap[key];
    return true;

  }
  return false;
}

template <typename K, typename V>
int ExtendibleHash<K, V>::getIdx(const K &key) const{
  lock_guard<mutex> lck(tlock);
  return HashKey(key) & ((1 << globalDepth) - 1);
}

template <typename K, typename V>
bool ExtendibleHash<K, V>::Remove(const K &key) {
  int idx = getIdx(key);
  lock_guard<mutex> lck(buckets[idx]->tlock);
  shared_ptr<Bucket> cur = buckets[idx];
  if (cur->tmap.find(key) == cur->tmap.end()) {
    return false;
  }
  cur->tmap.erase(key);
  return true;
}

template <typename K, typename V>
void ExtendibleHash<K, V>::Insert(const K &key, const V &value) {
  int idx = getIdx(key);
  shared_ptr<Bucket> cur = buckets[idx];
  while (true) {
    lock_guard<mutex> lck(cur->tlock);
    if (cur->tmap.find(key) != cur->tmap.end() || cur->tmap.size() < bucketSize) {
      cur->tmap[key] = value;
      break;
    }
    int mask = (1 << (cur->localDepth));
    cur->localDepth++;

    {
      lock_guard<mutex> lck2(tlock);
      if (cur->localDepth > globalDepth) {

        size_t num = buckets.size();
        for (size_t i = 0; i < num; i++) {
          buckets.push_back(buckets[i]);
        }
        globalDepth++;

      }
      bucketNum++;
      auto newBuc = make_shared<Bucket>(cur->localDepth);

      typename map<K, V>::iterator it;
      for (it = cur->tmap.begin(); it != cur->tmap.end(); ) {
        if (HashKey(it->first) & mask) {
          newBuc->tmap[it->first] = it->second;
          it = cur->tmap.erase(it);
        } else it++;
      }
      for (size_t i = 0; i < buckets.size(); i++) {
        if (buckets[i] == cur && (i & mask))
          buckets[i] = newBuc;
      }
    }
    idx = getIdx(key);
    cur = buckets[idx];
  }
}
template class ExtendibleHash<int, std::string>;
template class ExtendibleHash<int, std::list<int>::iterator>;
template class ExtendibleHash<int, int>;
}
