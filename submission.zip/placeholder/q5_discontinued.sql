SELECT ProductName,CompanyName,ContactName
FROM(
	SELECT Product.ProductName,Customer.CompanyName,Customer.ContactName
	FROM Product, OrderDetail,'Order',Customer
	WHERE Product.Discontinued = 1 AND Product.Id = OrderDetail.ProductId AND 'Order'.Id = OrderDetail.OrderId AND 'Order'.CustomerId = Customer.Id
	ORDER BY Product.ProductName, 'Order'.Orderdate)
GROUP BY ProductName
	