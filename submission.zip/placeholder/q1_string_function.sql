SELECT substr(ShipName,1,instr(ShipName,'-')-1) 
FROM 'Order'
WHERE ShipName like '%-%' 
Order by  ShipName;