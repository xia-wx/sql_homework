SELECT group_concat(pn) 'ProductNames ordered by the Company "Queen Cozinha" on 2014-12-25'
FROM(SELECT Product.ProductName pn
	FROM OrderDetail,Product
	WHERE OrderDetail.OrderId IN(
		SELECT 'Order'.Id
		FROM Customer,'Order'
		WHERE Customer.Id = 'Order'.CustomerId AND Customer.CompanyName = 'Queen Cozinha' AND 'Order'.Orderdate like '2014-12-25%') 
		AND Product.Id = OrderDetail.ProductId
	ORDER BY Product.ProductName);
