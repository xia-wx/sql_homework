select S.CompanyName,
round(round(sum(CASE WHEN (ShippedDate>RequiredDate) THEN 1 ELSE 0 END),4)/count(*)*100,2) as 'date percent'
FROM 'Order' O,Shipper S
WHERE O.ShipVia = S.id
GROUP by ShipVia
Order by round(round(sum(CASE WHEN (ShippedDate>RequiredDate) THEN 1 ELSE 0 END),4)/count(*)*100,2) DESC;

