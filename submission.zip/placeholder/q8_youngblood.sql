SELECT RegionDescription,FirstName,LastName,BirthDate
FROM(
	SELECT DISTINCT Region.RegionDescription,Employee.FirstName,Employee.LastName,Employee.BirthDate
	FROM Employee,EmployeeTerritory,Territory,Region
	WHERE   Employee.Id = EmployeeTerritory.EmployeeId 
		AND EmployeeTerritory.TerritoryId = Territory.Id
		AND Territory.RegionId = Region.Id
	ORDER BY Region.RegionDescription,Employee.BirthDate DESC)
GROUP BY RegionDescription;