SELECT ifnull(CuAO.CompanyName,'MISSAING_NAME') CompanyName,
		ifnull(CuAO.CustomerId,'MISSAING_NAME') CustomerId,
		round(sum(OD.Quantity*OD.UnitPrice),2) total_expenditures
FROM OrderDetail OD LEFT JOIN (
	SELECT Customer.CompanyName CompanyName,Customer.Id CustomerId,'Order'.Id OrderId 
	FROM ('Order') LEFT JOIN Customer ON Customer.Id = 'Order'.CustomerId) CuAO ON OD.OrderId = CuAO.OrderId
GROUP BY CompanyName
ORDER BY total_expenditures
LIMIT 23;