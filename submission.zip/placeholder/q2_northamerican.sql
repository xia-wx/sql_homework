SELECT id ,ShipCountry,
CASE ShipCountry WHEN 'USA' THEN 'NorthAmerica'
                 WHEN 'Mexico' THEN 'NorthAmerica'
				 WHEN 'Canada' THEN 'NorthAmerica'
				 ELSE 'Otherplace' END as 'ifNorthAmerica'
FROM 'Order'
WHERE id>=15445
Order by id
LIMIT 0,20;
