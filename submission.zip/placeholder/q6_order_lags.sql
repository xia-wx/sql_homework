select Id,OrderDate,lag(OrderDate,1,'2012-07-22 23:11:15') over (ORDER BY OrderDate) as previous_OrderDate
	,round(julianday(OrderDate)-julianday(lag(OrderDate,1,'2012-07-22 23:11:15') over (ORDER BY OrderDate)),2)
from 'Order'
where CustomerId = 'BLONP'
ORDER BY OrderDate;