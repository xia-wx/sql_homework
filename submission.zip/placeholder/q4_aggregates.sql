SELECT C.CategoryName,count(*) as 'The number of products',
round(avg(UnitPrice),2) as 'Average unit price',
min(UnitPrice) as 'Minimum unit price',
max(UnitPrice) as 'Maximum unit price',
sum(CASE WHEN UnitsOnOrder >= 10 THEN UnitsOnOrder ELSE 0 END) as 'Total units on order for categories containing greater than 10 products'
FROM Category C,Product P
WHERE C.Id = P.CategoryId
GROUP by C.Id;